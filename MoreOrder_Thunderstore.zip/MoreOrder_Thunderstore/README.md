# MoreOrder

Adds customizable chances to spawn Shrines of Order.

Doesn't modify the default spawns — just adds more shrines!

You can customize the spawn probability for each stage.

The probabilities remain the same for maps within the same stage (like Distant Roost and Titanic Plains in Stage 1).
